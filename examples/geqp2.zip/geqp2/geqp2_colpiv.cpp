// Plugins for <T>LAPACK (must come before <T>LAPACK headers)
#include <tlapack/plugins/legacyArray.hpp>

// <T>LAPACK
#include <tlapack/blas/copy.hpp>
#include <tlapack/blas/syrk.hpp>
#include <tlapack/blas/trmm.hpp>
#include <tlapack/blas/trsm.hpp>
#include <tlapack/lapack/geqrf.hpp>
#include <tlapack/lapack/lacpy.hpp>
#include <tlapack/lapack/lange.hpp>
#include <tlapack/lapack/lansy.hpp>
#include <tlapack/lapack/larf.hpp>
#include <tlapack/lapack/laset.hpp>
#include <tlapack/lapack/ung2r.hpp>  //get rid of?
#include <tlapack/lapack/unmqr.hpp>
#include <tlapack/lapack/geqr2.hpp>
#include <tlapack/lapack/larfg.hpp>

// C++ headers
#include <algorithm>
#include <chrono>  // for high_resolution_clock
#include <iostream>
#include <memory>
#include <numeric>
#include <vector>

//------------------------------------------------------------------------------

/// Print matrix A in the standard output
template <typename matrix_t>
void printMatrix(const matrix_t& A)
{
    using idx_t = tlapack::size_type<matrix_t>;
    const idx_t m = tlapack::nrows(A);
    const idx_t n = tlapack::ncols(A);

    for (idx_t i = 0; i < m; ++i) {
        std::cout << std::endl;
        for (idx_t j = 0; j < n; ++j)
            std::cout << A(i, j) << " ";
    }
}

//------------------------------------------------------------------------------
template <typename T>
void run(size_t m, size_t n)
{
    using std::size_t;
    using matrix_t = tlapack::LegacyMatrix<T>;
    using real_t = tlapack::real_type<T>;
    using idx_t = tlapack::size_type<matrix_t>;
    using range = tlapack::pair<idx_t, idx_t>;

    // Functors for creating new matrices
    tlapack::Create<matrix_t> new_matrix;

    // Turn it off if m or n are large
    bool verbose = true;

    // Arrays
    std::vector<T> tau(n);

    // Matrix
    std::vector<T> A_;
    auto A = new_matrix(A_, m, n);
    std::vector<idx_t> perm(n);

    // Initialize arrays with junk
    for (size_t j = 0; j < n; ++j) {
        for (size_t i = 0; i < m; ++i) {
            A(i, j) = static_cast<T>(0xDEADBEEF);
        }
        tau[j] = static_cast<T>(0xFFBADD11);
    }

    // Generate a random matrix in A
    for (size_t j = 0; j < n; ++j) {
        for (size_t i = 0; i < m; ++i)
            A(i, j) = static_cast<T>(rand()) / static_cast<T>(RAND_MAX);
    }

    if (m >= 3 && n >= 3) {
        for (size_t j = 0; j < n; ++j)
            for (size_t i = 0; i < m; ++i)
                A(i, j) = static_cast<T>(0);

        A(0, 0) = static_cast<T>(1.0);
        A(1, 0) = static_cast<T>(2.0);
        A(2, 0) = static_cast<T>(2.0);
        A(0, 1) = static_cast<T>(-4.0);
        A(1, 1) = static_cast<T>(3.0);
        A(2, 1) = static_cast<T>(2.0);
        A(0, 2) = static_cast<T>(3.0);
        A(1, 2) = static_cast<T>(2.0);
        A(2, 2) = static_cast<T>(1.0);
    }

    

    // Create a for loop to encase all the code in run so that we can call this
    // function in main. This for loop only needs to decrease the columns of A
    // by 1 and the size of tau by 1 since we only need n-1 householder
    // reflectors to compute the last column of Q and the last element of R.
    for (size_t j = 0; j < n - 1; ++j) {
        // print A before sorting
        if (verbose) {
            std::cout << std::endl << "A before sorting =";
            printMatrix(A);
        }

        // Compute norm of each column of A and keep only the compact pair
        // buffer we need.
        std::vector<std::pair<real_t, idx_t>> col_info(n);
        for (idx_t j = 0; j < n; ++j) {
            auto colN = slice(A, range(0, m), j);
            col_info[j] = {tlapack::nrm2(colN), j};
        }

        // Sort the column norms in descending order.
        std::sort(col_info.begin(), col_info.end(),
                  [](const std::pair<real_t, idx_t>& a,
                     const std::pair<real_t, idx_t>& b) {
                      return a.first > b.first;
                  });

        // Convert the sorted order into a compact permutation vector.
        for (idx_t j = 0; j < n; ++j)
            perm[j] = col_info[j].second;

        // print out sort perm with original column indices
        if (verbose) {
            std::cout << std::endl << "Column permutation =";
            for (idx_t j = 0; j < n; ++j)
                std::cout << perm[j] << " ";
        }

        // Column permutation
        for (idx_t j = 0; j < n; ++j) {
            while (perm[j] != j) {
                idx_t k = perm[j];
                // swap columns j and k in A
                for (idx_t i = 0; i < m; ++i)
                    std::swap(A(i, j), A(i, k));
                // swap indices in perm
                std::swap(perm[j], perm[k]);
            }
        }

        // print A and column norms
        if (verbose) {
            std::cout << std::endl << "A after sorting =";
            printMatrix(A);
            std::cout << std::endl << "Column norms =";
            for (idx_t j = 0; j < n; ++j)
                std::cout << col_info[j].first << " ";
        }
        // Generate the Householder reflector for the j-th column of A.
        auto col_j = slice(A, range(j, m), j);
        tlapack::larfg(tlapack::Direction::Forward,
                       tlapack::StoreV::Columnwise, col_j, tau[j]);

        // Apply the reflector to the remaining columns of the active block.
        auto A_block = slice(A, range(j, m), range(j + 1, n));
        tlapack::larf(tlapack::Side::Left, tlapack::Direction::Forward,
                      tlapack::StoreV::Columnwise, col_j, tau[j], A_block);

        // print A_block after applying the householder reflector
        if (verbose) {
            std::cout << std::endl << "A_block after applying the householder reflector =";
            printMatrix(A_block);
        }
    }
    //print column j of A after the for loop
}

int main(int argc, char** argv)
{
    int m, n;

    // Default arguments
    m = (argc < 2) ? 3 : atoi(argv[1]);
    n = (argc < 3) ? 3 : atoi(argv[2]);

    srand(3);  // Init random seed

    std::cout.precision(5);
    std::cout << std::scientific << std::showpos;

    printf("run< float  >( %d, %d )", m, n);
    run<float>(m, n);
    printf("-----------------------\n");

    // printf("run< double >( %d, %d )", m, n);
    // run<double>(m, n);
    // printf("-----------------------\n");

    // printf("run< complex<float> >( %d, %d )", m, n);
    // run<std::complex<float>>(m, n);
    // printf("-----------------------\n");

    // printf("run< complex<double> >( %d, %d )", m, n);
    // run<std::complex<double>>(m, n);
    // printf("-----------------------\n");

    // printf("run< complex<long double> >( %d, %d )", m, n);
    // run<std::complex<long double>>(m, n);
    // printf("-----------------------\n");

    return 0;
}
